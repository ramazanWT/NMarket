<?php

declare(strict_types=1);

namespace HakanBabus\NetheriteMarket;

use pocketmine\Server;
use pocketmine\player\Player;
use pocketmine\plugin\PluginBase;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use onebone\economyapi\EconomyAPI;
use pocketmine\item\Item;
use pocketmine\inventory\Inventory;

class Main extends PluginBase{

	public function oncommand(commandsender $sender, command $cmd, string $label, array $args) : bool
	{

		switch($cmd->getname())
		{
			case "nmarket":
			 if($sender Instanceof player);
			 {
			   		$this->nmarket($sender);
			 }
		}
		return true;
	}




 	public function nmarket($player)
	{
		$paraal = EconomyAPI::getInstance()->myMoney($player);
		$form = $this->getserver()->GetPluginManager()->getplugin("FormAPI")->createsimpleform(function (player $player, int $data = null){
			if($data === null)
			{
				return true;
			}
			Switch($data)
			{
				case 0:
				    $this->aletler($player);
				    break;

				case 1:  
				    $this->zirhlar($player);
				    break; 

				case 2:

				    break;

    

			}
		});
		$form->settitle("Netherite Market");
		$form->setcontent("Hoşgeldin, Kategori Seçerek Eşya §aAlabilirsin. \nParan: §r" . $paraal);
		$form->addButton("§lAletler", 0, "textures/items/netherite_sword.png");
		$form->addbutton("§lZırhlar", 0, "textures/items/netherite_chestplate.png");
		$form->addbutton("§4§lÇık", 0, "textures/ui/cancel.png");
		$form->sendtoplayer($player);
		return $form;
    }


 	public function aletler($player)
	{

		$paraal = EconomyAPI::getInstance()->myMoney($player);
		$form = $this->getserver()->GetPluginManager()->getplugin("FormAPI")->createsimpleform(function (player $player, int $data = null){
			if($data === null)
			{
				return true;
			}
			Switch($data)
			{
				case 0:
				    $this->nmarket($player);
				    break;

				case 1:
				$paraal = EconomyAPI::getInstance()->myMoney($player);
				    if($paraal > 150000)
				    {  
				    $player->getInventory()->addItem(Item::get(743,0,1));
				    $player->sendMessage("Başarıyla Eşyanı §aAldın!");
				    EconomyAPI::getInstance()->reduceMoney($player, "150000");
				}else{
					$player->sendMessage("Paran §4Yetersiz.");
				}

				    break; 

				case 2:
				$paraal = EconomyAPI::getInstance()->myMoney($player);
				    if($paraal > 170000)
				    {
                    $player->getInventory()->addItem(Item::get(745,0,1));
                    $player->sendMessage("Başarıyla Eşyanı §aAldın!");
                    EconomyAPI::getInstance()->reduceMoney($player, "170000");
                }else{
					$player->sendMessage("Paran §4Yetersiz.");
				}
				    break;
				

				case 3:
				$paraal = EconomyAPI::getInstance()->myMoney($player);
				if($paraal > 100000)
				    {
				    $player->getInventory()->addItem(Item::get(746,0,1));
				    $player->sendMessage("Başarıyla Eşyanı §aAldın!");
				    EconomyAPI::getInstance()->reduceMoney($player, "100000");
				}else{
					$player->sendMessage("Paran §4Yetersiz.");
				}
				    break;
				

				case 4: 
				$paraal = EconomyAPI::getInstance()->myMoney($player); 
				if($paraal > 80000)
				    {
				    $player->getInventory()->addItem(Item::get(744,0,0));
				    $player->sendMessage("Başarıyla Eşyanı §aAldın!");
				    EconomyAPI::getInstance()->reduceMoney($player, "80000");
				}else{
					$player->sendMessage("Paran §4Yetersiz.");
				}
				    break; 
				

				case 5:
				$paraal = EconomyAPI::getInstance()->myMoney($player);
				if($paraal > 50000)
				    {
                    $player->getInventory()->addItem(Item::get(747,0,0));
                    $player->sendMessage("Başarıyla Eşyanı §aAldın!");
                    EconomyAPI::getInstance()->reduceMoney($player, "50000");
                }else{
					$player->sendMessage("Paran §4Yetersiz.");
				}
				    break;    
				

    

			}
		});
		$form->settitle("Netherite Market");
		$form->setcontent("Hoşgeldin, Buton Seçerek Eşya §aAlabilirsin. \n§aParan: §r" . $paraal);
		$form->addbutton("§l§8Geri Dön", 0, "textures/ui/cancel.png");		
		$form->addButton("§lKılıç\n§r150.000", 0, "textures/items/netherite_sword.png");
		$form->addbutton("§lKazma\n§r170.000", 0, "textures/items/netherite_pickaxe.png");
		$form->addbutton("§lBalta\n§r100.000", 0, "textures/items/netherite_axe.png");
		$form->addbutton("§lKürek\n§r80.000", 0, "textures/items/netherite_shovel");	
		$form->addbutton("§lÇapa\n§r50.000", 0, "textures/items/netherite_hoe");				
		$form->sendtoplayer($player);
		return $form;
    }

 	public function zirhlar($player)
	{

		$paraal = EconomyAPI::getInstance()->myMoney($player);
		$form = $this->getserver()->GetPluginManager()->getplugin("FormAPI")->createsimpleform(function (player $player, int $data = null){
			if($data === null)
			{
				return true;
			}
			Switch($data)
			{
				case 0:
				    $this->nmarket($player);
				    break;

				case 1: 
				$paraal = EconomyAPI::getInstance()->myMoney($player);
				if($paraal > 100000){ 
				$paraal = EconomyAPI::getInstance()->myMoney($player);
				    $player->getInventory()->addItem(Item::get(748,0,1));
				    $player->sendMessage("Başarıyla Eşyanı §aAldın!");
              EconomyAPI::getInstance()->reduceMoney($player, "100000");
				}else{
					$player->sendMessage("Paran §4Yetersiz.");
				}
				    break; 

				case 2:
				$paraal = EconomyAPI::getInstance()->myMoney($player);
				if($paraal > 125000){
				$paraal = EconomyAPI::getInstance()->myMoney($player);
                    $player->getInventory()->addItem(Item::get(749,0,1));
                    $player->sendMessage("Başarıyla Eşyanı §aAldın!");
                    EconomyAPI::getInstance()->reduceMoney($player, "125000");
                }else{
					$player->sendMessage("Paran §4Yetersiz.");
				}
				    break;

				case 3:
				$paraal = EconomyAPI::getInstance()->myMoney($player);
				if($paraal > 85000){
				$paraal = EconomyAPI::getInstance()->myMoney($player);
				    $player->getInventory()->addItem(Item::get(750,0,1));
				    $player->sendMessage("Başarıyla Eşyanı §aAldın!");
					EconomyAPI::getInstance()->reduceMoney($player, "85000");
				}else{
					$player->sendMessage("Paran §4Yetersiz.");
				}
				    break;

				case 4:  
				$paraal = EconomyAPI::getInstance()->myMoney($player);
				if($paraal > 60000){
				    $player->getInventory()->addItem(Item::get(751,0,1));
				    $player->sendMessage("Başarıyla Eşyanı §aAldın!");
                    EconomyAPI::getInstance()->reduceMoney($player, "60000");
				}else{
					$player->sendMessage("Paran §4Yetersiz.");
				}
				    break; 
    

    

			}
		});
		$form->settitle("Netherite Market");
		$form->setcontent("Hoşgeldin, Buton Seçerek Eşya §aAlabilirsin. \n§aParan: §r" . $paraal);
		$form->addbutton("§l§8Geri Dön", 0, "textures/ui/cancel.png");		
		$form->addButton("§lKask\n§r100.000", 0, "textures/items/netherite_helmet.png");
		$form->addbutton("§lGöğüslük\n§r125.000", 0, "textures/items/netherite_chestplate.png");
		$form->addbutton("§lPantolon\n§r85.000", 0, "textures/items/netherite_leggings.png");
		$form->addbutton("§lBot\n§r60.000", 0, "textures/items/netherite_boots.png");					
		$form->sendtoplayer($player);
		return $form;
    }




}
